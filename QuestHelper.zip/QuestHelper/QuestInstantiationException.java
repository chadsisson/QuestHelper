package net.runelite.client.plugins.custom.QuestHelper;


public class QuestInstantiationException extends Exception
{
	public QuestInstantiationException(Throwable cause)
	{
		super(cause);
	}
}
