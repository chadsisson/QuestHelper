package net.runelite.client.plugins.custom.QuestHelper.steps;

import java.util.Collection;

public interface OwnerStep
{
	Collection<QuestStep> getSteps();
}
